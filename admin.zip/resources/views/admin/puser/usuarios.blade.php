@extends('admin.layouts.maind')

@section('section')

@livewire('permisos-user')

@endsection