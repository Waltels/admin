
<?php $__env->startSection('section'); ?>

<div class="page-content">

    <nav class="page-breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="#">Tables</a></li>
            <li class="breadcrumb-item active" aria-current="page">Data Table</li>
        </ol>
    </nav>
    <div class=" card col-md-5 mx-auto mb-2">
    <a class="btn btn-primary px-2" href="<?php echo e(route('admin.comunicados.create')); ?>">Registrar comunicado</a>
    </div>

    <div class="row">
        <div class="col-md-9 grid-margin stretch-card mx-auto">
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title text-center">historial de comunicados emanados por la dirección de la Unidad Educativa Alemania</h6>
                    <div class="table-responsive">
                    <table id="dataTableExample" class="table">
                        <thead>
                        <tr>
                            <th>Numero</th>
                            <th>nombre</th>
                            <th>fecha</th>
                            <th>Acción</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $comunicados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comunicado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($comunicado->id); ?></td>
                            <td><?php echo e($comunicado->name); ?></td>
                            <td><?php echo e($comunicado->fecha); ?></td>

                            <td width='10px'>
                                <a href="<?php echo e(route('admin.comunicados.show', $comunicado)); ?>" class="btn btn-sm btn-primary" ><i data-feather="eye"></i></a>
                            </td>
                            <td width='10px'>
                                <a href="<?php echo e(route('admin.comunicados.edit', $comunicado)); ?>" class="btn btn-sm btn-success" ><i data-feather="edit"></i></a>
                            </td>
                            <td width='10px'>
                                <?php if (isset($component)) { $__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.danger-button','data' => ['class' => 'btn btn-danger','onclick' => 'deleteDocumento()']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('danger-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'btn btn-danger','onclick' => 'deleteDocumento()']); ?>
                                    <i data-feather="delete"></i>
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11)): ?>
<?php $attributes = $__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11; ?>
<?php unset($__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11)): ?>
<?php $component = $__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11; ?>
<?php unset($__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11); ?>
<?php endif; ?>
                            </td> 
                           
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        </table>
                        <form   action="<?php echo e(route('admin.comunicados.destroy', $comunicado)); ?>"
                                        method="POST" 
                                        id="FormDelete">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>   
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->startPush('js'); ?>
    <script>
        function deleteDocumento(){
            let form = document.getElementById('FormDelete');
            form.submit();
        }
    </script>  
<?php $__env->stopPush(); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.maind', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admin\resources\views/admin/comunicados/index.blade.php ENDPATH**/ ?>