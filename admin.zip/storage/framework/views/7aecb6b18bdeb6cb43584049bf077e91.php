<div>


    <div class="page-content">

        
        <div class="dropdown">
            <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Seleccione al Docente
            </button>


            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="dropdown-item" id="user_id"  wire:click="$set('user_id',<?php echo e($user->id); ?>)"><?php echo e($user->name); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

        </div>
        <!--[if BLOCK]><![endif]--><?php if($nombre): ?>
            <div class="text-center py-3">
                <div class="card-header">
                    <div class="card-title">
                        <h4><span>Docente: </span><?php echo e($nombre); ?></h4>
                        <p>En este espacio se detallan todos los registros de permisos  que el Docente  solicito a la Direccion de la Unidad Educativa Alemania</p>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <div class="text-center py-3">
                <div class="card-header">
                    <div class="card-title">
                        <h4>RESUMEN DE REGISTROS DE PERMISOS POR DOCENTE</h4>
                        <p>Para poder obtener los datos de un Docente, seleccione el nombre para lisatar los registro que tiene</p>
                    </div>
                </div>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        

            <div class="row">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $permisos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permiso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="col-12 col-md-6 col-xl-3 py-3">
                <div class="card">
                    <div class="card-header">
                    Fecha de solicitud del Permiso: <?php echo e($permiso->created_at); ?>

                    </div>
                    <div class="card-body">
                        <h5 class="card-title">DATOS DEL PERMISO</h5>
                        <p class="card-text mb-3">El docente <?php echo e($permiso->user->name); ?> solicito permiso por  motivo <?php echo e($permiso->motivo); ?>, durante <?php echo e($permiso->dias); ?> dias.</p>
                    </div>
                    <div class="card-footer d-grid">
                        <a href="<?php echo e(route('admin.peuser.show', $permiso)); ?>" type="button" class="w-full btn btn-primary ">Detalle del permiso</a>  
                    </div> 
                </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
            </div>
    </div>

</div>
<?php /**PATH C:\xampp\htdocs\admin\resources\views/livewire/permisos-user.blade.php ENDPATH**/ ?>