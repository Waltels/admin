
<?php $__env->startSection('section'); ?>
    <div class="page-content ">

    <div class="row mx-auto">
        <div class="col-md-6 grid-margin stretch-card mx-auto">
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title">asignacion de roles a usuarios</h6>
                    <form action="<?php echo e(route('admin.users.update', $user)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label">Nombre de Usuario</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" value="<?php echo e(old('name', $user->name)); ?>" name="name" placeholder="Usuario">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label  class="col-sm-3 col-form-label">Correo</label>
                                <div class="col-sm-9">
                                    <input type="email" class="form-control" value="<?php echo e(old('email', $user->email)); ?>" name="email" placeholder="Correo">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label  class="col-sm-3 col-form-label">Contraseña</label>
                                <div class="col-sm-9">
                                    <input type="password" name="password" class="form-control"  placeholder="Contraseña">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label  class="col-sm-3 col-form-label">Confirmar contraseña</label>
                                <div class="col-sm-9">
                                    <input type="password" name="password_confirmation" class="form-control"  placeholder="Confirmar contraseña">
                                </div>
                            </div>
                            <div  class="py-2">
                                <h5 class="car-title">Roles para Usuarios</h4>
                            </div>
                            <div class="row mb-3 px-4">
                                <ul>   
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <label>
                                                <?php if (isset($component)) { $__componentOriginal74b62b190a03153f11871f645315f4de = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal74b62b190a03153f11871f645315f4de = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.checkbox','data' => ['name' => 'roles[]','value' => ''.e($role->id).'','checked' => in_array($role->id, old('roles', $user->roles->pluck('id')->toArray()))]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'roles[]','value' => ''.e($role->id).'','checked' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(in_array($role->id, old('roles', $user->roles->pluck('id')->toArray())))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal74b62b190a03153f11871f645315f4de)): ?>
<?php $attributes = $__attributesOriginal74b62b190a03153f11871f645315f4de; ?>
<?php unset($__attributesOriginal74b62b190a03153f11871f645315f4de); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal74b62b190a03153f11871f645315f4de)): ?>
<?php $component = $__componentOriginal74b62b190a03153f11871f645315f4de; ?>
<?php unset($__componentOriginal74b62b190a03153f11871f645315f4de); ?>
<?php endif; ?>
                                                        <?php echo e($role->name); ?>

                                            </label>
                                        </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                            </div>
                            <button type="submit" class="btn btn-primary me-2">Actualizar</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.maind', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admin\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>