<footer class="footer border-top">
        <div class="container d-flex flex-column flex-md-row align-items-center justify-content-between py-3 small">
          <p class="text-muted mb-1 mb-md-0">Copyright © 2024 <a href="https://www.nobleui.com" target="_blank">serconed</a>.</p>
          <p class="text-muted">Walter Laura Soto <i class="mb-1 text-primary ms-1 icon-sm" data-feather="slack"></i></p>
        </div>
			</footer><?php /**PATH C:\xampp\htdocs\admin\resources\views/admin/layouts/footer.blade.php ENDPATH**/ ?>