
<?php $__env->startSection('section'); ?>
<div class="page-content">

    <nav class="page-breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="#">Tables</a></li>
            <li class="breadcrumb-item active" aria-current="page">Data Table</li>
        </ol>
    </nav>


    <div class="row">
        <div class="col-md-9 grid-margin stretch-card mx-auto">
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title text-center">historial de envio de documentos a la dirección de la Unidad Educativa Alemania</h6>
                    <p class="mb-5 text-gray-400 text-center"> en esta seccion se encuentra todos los archivos enviados por el Ususraio</p>
                    <div class="table-responsive">
                    <table id="dataTableExample" class="table">
                        <thead>
                        <tr>
                            <th>Nº de deocumento</th>
                            <th>Docente</th>
                            <th>Descripcion del Documento</th>
                            <th>Fecha de envio del Documento</th>
                            <th>Acción</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($file->id); ?></td>
                            <td><?php echo e($file->user_id); ?></td>
                            <td><?php echo e($file->description); ?></td>
                            <td><?php echo e($file->created_at); ?></td>
                            <td>
                                <a href="<?php echo e(url("/$file->path")); ?>" class="btn btn-sm btn-primary" target="_blank"><i class="fa fa-download"></i> Ver</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>




<!-- Custom js for this page -->
<script src="<?php echo e(asset('js/data-table.js')); ?>"></script>
<!-- End custom js for this page -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.maind', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admin\resources\views/files/archivos/index.blade.php ENDPATH**/ ?>