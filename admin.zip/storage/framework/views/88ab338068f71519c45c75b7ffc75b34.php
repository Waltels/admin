                        <?php echo csrf_field(); ?>
                        <div class="px-6 mb-3">
                            <label class="mb-2">Nombre del nuevo Rol</label>
                            <div class="col-sm-9">
                                <input type="text" name="name"  class="form-control"   placeholder="Nombre">
                                
                            </div>
                        </div>
                        <div class="row mb-3 form-check">
                            <div class="col-sm-9 px-7">
                                <label class="col-sm-3 col-form-label">Permisos</label>
                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="">
                                    <input name="permissions[]" class="form-check-input" value="<?php echo e($permission->id); ?>" type="checkbox" id="id">
                                    <label for="id"><?php echo e($permission->name); ?></label>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary me-2">Crear Rol</button><?php /**PATH C:\xampp\htdocs\admin\resources\views/admin/roles/partials/form.blade.php ENDPATH**/ ?>