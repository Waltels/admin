
<?php $__env->startSection('section'); ?>
<div class="page-content ">

    <div class="row mx-auto">
        <div class="col-md-6 grid-margin stretch-card mx-auto">
            <div class="card">
                <div class="card-body">
                            <h6 class="card-title">lista DE USUARIOS</h6>
                            <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>Nº</th>
                                                <th>Nombre</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <th><?php echo e($user->id); ?></th>
                                                <td><?php echo e($user->name); ?></td>
                                                <td width='10px'>
                                                    <a href="<?php echo e(route('admin.users.edit', $user)); ?>" class="btn btn-success">Asignar Rol</a>
                                                </td>   
                                            </tr> 
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                                <tr>
                                                    <td colspan="4">No hay ningun rol registrado</td>
                                                </tr>
                                            <?php endif; ?>  
                                        </tbody>
                                    </table>
                                    
                            </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.maind', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admin\resources\views/admin/users/index.blade.php ENDPATH**/ ?>