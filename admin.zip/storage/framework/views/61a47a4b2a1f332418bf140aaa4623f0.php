
<?php $__env->startSection('section'); ?>
<div class="page-content ">
    <div class=" card col-md-5 mx-auto mb-2">
        <a class="btn btn-primary px-2" href="<?php echo e(route('admin.roles.create')); ?>">Registrar nuevo Rol</a>
        </div>
    <div class="row mx-auto">
        <div class="col-md-6 grid-margin stretch-card mx-auto">
            <div class="card">
                <div class="card-body">
                            <h6 class="card-title">ROLES DE USUARIO</h6>
                            <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>Nº</th>
                                                <th>Nombre</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <th><?php echo e($role->id); ?></th>
                                                <td><?php echo e($role->name); ?></td>
                                                <td width='10px'>
                                                    <a href="<?php echo e(route('admin.roles.edit', $role)); ?>" class="btn btn-success">editar</a>
                                                </td> 
                                                <td width='10px'>
                                                    <?php if (isset($component)) { $__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.danger-button','data' => ['class' => 'btn btn-danger','onclick' => 'deleteRole()']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('danger-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'btn btn-danger','onclick' => 'deleteRole()']); ?>
                                                        Eliminar
                                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11)): ?>
<?php $attributes = $__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11; ?>
<?php unset($__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11)): ?>
<?php $component = $__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11; ?>
<?php unset($__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11); ?>
<?php endif; ?>
                                                </td>  
                                            </tr> 
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                                <tr>
                                                    <td colspan="4">No hay ningun rol registrado</td>
                                                </tr>
                                            <?php endif; ?>  
                                        </tbody>
                                    </table>
                                    <form   action="<?php echo e(route('admin.roles.destroy', $role)); ?>" 
                                    method="POST" 
                                    id="FormDelete">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>   
                                    </form>
                                    
                            </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->startPush('js'); ?>
    <script>
        function deleteRole(){
            let form = document.getElementById('FormDelete');
            form.submit();
        }
    </script>  
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.maind', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admin\resources\views/admin/roles/index.blade.php ENDPATH**/ ?>