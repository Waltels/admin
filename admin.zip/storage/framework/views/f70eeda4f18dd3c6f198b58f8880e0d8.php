<div>
    <div class="page-content">

        
        <div class="dropdown">
            <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Seleccione al Docente
            </button>


            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="dropdown-item" id="user_id"  wire:click="$set('user_id',<?php echo e($user->id); ?>)"><?php echo e($user->name); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

        </div>
        <!--[if BLOCK]><![endif]--><?php if($nombre): ?>
            <div class="text-center py-3">
                <div class="card-header">
                    <div class="card-title">
                        <h4><span>Docente: </span><?php echo e($nombre); ?></h4>
                        <p>En este espacio se detallan todos los registros de faltas del Docente  registradas en la Direccion de la Unidad Educativa Alemania</p>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <div class="text-center py-3">
                <div class="card-header">
                    <div class="card-title">
                        <h4>RESUMEN DE REGISTROS DE FALTAS POR DOCENTE</h4>
                        <p>Para poder obtener los datos de un Docente, seleccione el nombre para lisatar los registro que tiene</p>
                    </div>
                </div>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        

            <div class="row">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $faltasdocs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faltasdoc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="col-12 col-md-6 col-xl-3 py-3">
                <div class="card">
                    <div class="card-header">
                    Fecha de registro de la Falta: <?php echo e($faltasdoc->created_at); ?>

                    </div>
                    <div class="card-body">
                        <h5 class="card-title">DATOS DE LA FALTA</h5>
                        <p class="card-text mb-3">El docente <?php echo e($faltasdoc->user->name); ?> tiene registro de faltas por  motivo <?php echo e($faltasdoc->motivo); ?>, en fecha <?php echo e($faltasdoc->fecha); ?>.</p>
                    </div>
                    <div class="card-footer d-grid">
                        <a href="<?php echo e(route('admin.fuser.show', $faltasdoc)); ?>" type="button" class="w-full btn btn-primary ">Detalle de la Falta</a>  
                    </div> 
                </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
            </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\admin\resources\views/livewire/faltasdoc-user.blade.php ENDPATH**/ ?>